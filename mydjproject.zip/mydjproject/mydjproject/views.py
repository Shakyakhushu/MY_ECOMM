''' URL routing : A mechanism to redirect from one 
application url to another '''

from django.http import HttpResponse

urlRoute="""<h2>Click on the link below to redirect</h2>
<a href="/">Home page</a><br/><br/>
<a href="/about/">About page</a><br/><br/>
<a href="/contact/">Contact page</a><br/><br/>
<a href="/service/">Service page</a><br/><br/>
<a href="/register/">Register page</a><br/><br/>
<a href="/login/">Login page</a>
"""

def home(request):
 return HttpResponse("<h1>/ or home/ url invoked</h1>"+urlRoute)

def about(request):
 return HttpResponse("<h1>about/ url invoked</h1>"+urlRoute)

def contact(request):
 return HttpResponse("<h1>contact/ url invoked</h1>"+urlRoute)

def service(request):
 return HttpResponse("<h1>service/ url invoked</h1>"+urlRoute)

def register(request):
 return HttpResponse("<h1>register/ url invoked</h1>"+urlRoute)  

def login(request):
 return HttpResponse("<h1>login/ url invoked</h1>"+urlRoute)